import { h } from "vue";
import { ElMessageBox } from "element-plus";

const useModel = async (late, callback) => {
  const t = await ElMessageBox({
    title: "title",
    message: () =>
      h(
        late,
        {
          callback,
        },
        null
      ),
    showCancelButton: false,
    closeOnClickModal: false,
    showConfirmButton: false,
  });
};

export { useModel };
