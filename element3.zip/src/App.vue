
<script setup>

import { useModel } from "/src/components/ele"
import { useModel2 } from "/src/components/naive"
import { ModelHelloWorld, ModelHelloWorld2 } from "/src/auto"
import { NButton, NSpace, NNumberAnimation } from "naive-ui"
import { ref } from "vue"
const nums = ref(10)
const onclick = () => {
  useModel(ModelHelloWorld, callback, { nums })
}
const onclick2 = () => {
  useModel2(ModelHelloWorld2, callback, { nums })
}

const callback = (e) => {

  console.log("callback", e)
}

//console.log(ModelHelloWorld)
</script>

<template>
  <div>
    <n-space>
      <el-button type="primary" @click="onclick">ele-UI</el-button>
      <n-button type="primary" size="medium" @click="onclick2">naive-ui</n-button>

      <div>{{ nums }}</div>
    </n-space>
    <div style="">

    </div>


  </div>
</template>

<style scoped></style>
